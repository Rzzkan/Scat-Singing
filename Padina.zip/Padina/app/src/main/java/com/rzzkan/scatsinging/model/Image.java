package com.rzzkan.scatsinging.model;

import android.graphics.drawable.Drawable;

public class Image {

    public int image;
    public Drawable imageDrw;
    public String name;
    public String brief;
    public Integer counter = null;

}
