package com.rzzkan.scatsinging.activity;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.rzzkan.scatsinging.R;
import com.rzzkan.scatsinging.fragment.theoryList;

public class Theory extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_theory);
        removeAllFragment(new theoryList(),"list");
    }

    public void removeAllFragment(Fragment replaceFragment, String tag) {
        FragmentManager manager = this.getSupportFragmentManager();
        FragmentTransaction ft = manager.beginTransaction();
        manager.popBackStackImmediate(null,FragmentManager.POP_BACK_STACK_INCLUSIVE);
        ft.replace(R.id.theoryFrame, replaceFragment);
        ft.commitAllowingStateLoss();
    }
}
